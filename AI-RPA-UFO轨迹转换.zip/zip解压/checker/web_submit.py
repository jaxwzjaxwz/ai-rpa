"""Independent checker for the web-submit case.

Reads the run directory produced by runner/run_case.py (or the sanitized example)
and decides whether the backend really accepted a matching submission.

It does NOT trust UFO's own "success" claim: it only looks at server-side events.
"""
import json
from pathlib import Path


def read_jsonl(path):
    path = Path(path)
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def check(run_dir):
    run_dir = Path(run_dir)
    manifest = json.loads((run_dir / "manifest.json").read_text(encoding="utf-8-sig"))
    events = read_jsonl(run_dir / "server_events.jsonl")

    want = {"name": manifest.get("name"), "message": manifest.get("message")}
    submissions = [e for e in events if e.get("event") == "submission"]
    matching = [e for e in submissions if e.get("fields") == want]
    accepted = [e for e in matching if e.get("accepted") is True and e.get("http_status") == 200]

    accepted_file = read_jsonl(run_dir / "accepted_submissions.jsonl")
    file_match = any(a.get("name") == want["name"] and a.get("message") == want["message"]
                     for a in accepted_file)

    passed = bool(accepted) and file_match if accepted_file else bool(accepted)

    return {
        "checker": "web_submit",
        "task_id": manifest.get("run_id"),
        "expected": manifest.get("expected"),
        "want_fields": want,
        "passed": passed,
        "actual": {
            "submission_count": len(submissions),
            "matching_count": len(matching),
            "accepted_count": len(accepted),
            "http_status": accepted[0]["http_status"] if accepted else None,
            "accepted_file_match": file_match,
        },
        "evidence": {
            "server_events": str(run_dir / "server_events.jsonl"),
            "accepted_submissions": str(run_dir / "accepted_submissions.jsonl")
            if (run_dir / "accepted_submissions.jsonl").exists() else None,
            "submissions": submissions,
        },
    }


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("run_dir")
    args = ap.parse_args()
    print(json.dumps(check(args.run_dir), ensure_ascii=False, indent=2))
