# 结果检查器

独立于 UFO：不信任代理自报的 `task_success`，只看服务端证据。

## 网页提交检查（`web_submit.py`）

输入：运行目录，需包含

- `manifest.json`：`name`、`message`、`expected`
- `server_events.jsonl`：后端事件
- （可选）`accepted_submissions.jsonl`

判定规则：

1. 事件里存在 `event == "submission"`；
2. `fields` 与 manifest 的 `name` / `message` 完全一致；
3. `accepted == true` 且 `http_status == 200`；
4. 若存在 `accepted_submissions.jsonl`，其中也要有对应记录。

输出：

```json
{
  "checker": "web_submit",
  "task_id": "...",
  "expected": "success",
  "want_fields": {"name": "UFO Tester", "message": "..."},
  "passed": true,
  "actual": {"submission_count": 1, "matching_count": 1, "accepted_count": 1,
             "http_status": 200, "accepted_file_match": true},
  "evidence": {"submissions": [...]}
}
```

## 用法

```powershell
python checker\web_submit.py runs\web_success_example
```

## 测试

```powershell
python tests\test_checker.py
```

覆盖两种情况：`accepted=true/200` 判通过；`accepted=false/503` 判失败。
