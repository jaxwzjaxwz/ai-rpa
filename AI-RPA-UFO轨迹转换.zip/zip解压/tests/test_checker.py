"""Offline tests for the web-submit checker (no network, no UFO)."""
import json
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(HERE))

from checker.web_submit import check  # noqa: E402

TMP = Path(__file__).resolve().parent / "_tmp"


def make_run(name, accepted, http_status):
    run = TMP / name
    if run.exists():
        shutil.rmtree(run)
    run.mkdir(parents=True)
    (run / "manifest.json").write_text(json.dumps({
        "run_id": "t1", "case": "web_success", "expected": "success",
        "name": "UFO Tester", "message": "TOKEN-1"}), encoding="utf-8")
    event = {"event": "submission", "fields": {"name": "UFO Tester", "message": "TOKEN-1"},
             "accepted": accepted, "http_status": http_status}
    (run / "server_events.jsonl").write_text(json.dumps(event) + "\n", encoding="utf-8")
    if accepted:
        (run / "accepted_submissions.jsonl").write_text(
            json.dumps({"name": "UFO Tester", "message": "TOKEN-1"}) + "\n", encoding="utf-8")
    return run


def main():
    TMP.mkdir(exist_ok=True)
    ok = check(make_run("pass", True, 200))
    assert ok["passed"] is True, ok
    print("PASS case: checker passed =", ok["passed"])

    bad = check(make_run("fail", False, 503))
    assert bad["passed"] is False, bad
    print("FAIL case: checker passed =", bad["passed"], "http =", bad["actual"]["http_status"])

    shutil.rmtree(TMP)
    print("all checker tests passed")


if __name__ == "__main__":
    main()
