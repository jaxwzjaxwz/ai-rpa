# 统一操作轨迹（UFO → 统一格式）

每一步至少包含：任务编号、步骤编号、动作、前截图、后截图、执行结果。

## 文件

| 文件 | 作用 |
|---|---|
| `schema.json` | 统一轨迹的 JSON Schema |
| `convert_ufo.py` | 把 UFO 运行目录转换成统一轨迹 |
| `README.md` | 本说明 |

## 转换规则（UFO 字段 → 统一字段）

| UFO 原始字段 | 统一轨迹字段 | 说明 |
|---|---|---|
| `manifest.run_id` | `task_id` | 任务编号 |
| `result.task_success` | `status` / `outcome.task_success` | 任务级结果 |
| 每一步 `clean_screenshot_path` | `step.pre_img` | 该步执行**前**的画面 |
| 下一步的 `clean_screenshot_path` | `step.post_img` | 该步执行**后**的画面；最后一步用 `action_step_final.png` |
| `action[].function` | `action.functions` | 动作名，如 `set_edit_text` / `click_input` |
| `function_call` | `action.calls` | 可读的动作调用串 |
| `action[].arguments` / `target` | `action.arguments` / `targets` | 参数与目标控件 |
| `action_success[0].result.status` | `action_status` | `success` / `error` |
| `result` | `result_text` | 该步的自然语言结果 |
| `status` | `agent_status` | `CONTINUE` / `FINISH` |
| `agent_type` / `app_root` | `agent` / `application` | 代理与进程 |

**过滤**：只保留带 `clean_screenshot_path` 的步骤（当前样例为 4 步，HostAgent 的窗口选择步骤被跳过）。

## 用法

```powershell
python trajectory\convert_ufo.py --run-dir inputs\web_success --out runs\web_success_example
```

输出：

```
runs/web_success_example/
├── trajectory.json     # 统一轨迹（schema.json 定义）
├── steps.csv           # 便于人工核对的一行一步表
└── screenshots/
    ├── step_0001_pre.png / step_0001_post.png
    └── ...
```

## 约定与限制

- UFO 原始日志**没有每步绝对时间戳**，只有整次运行的 `elapsed_seconds`；
- “前/后截图”按 UFO 的截图时序推断（当前步截图 = 动作前，下一步截图 = 动作后），已用样例人工核对；
- 截图会被复制并改名，原始文件不动。
