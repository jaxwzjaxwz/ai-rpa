"""Build a static HTML viewer from a unified trajectory.json."""
import argparse
import html
import json
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--trajectory", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    t = json.loads(Path(args.trajectory).read_text(encoding="utf-8"))
    base = Path(args.trajectory).resolve().parent
    parts = [f"""<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">
<title>{html.escape(t['task_id'])}</title><style>
body{{font-family:"Microsoft YaHei UI",sans-serif;margin:24px;background:#f6f8fb;color:#1b1f24}}
h1{{font-size:20px}} .meta{{color:#5b6572;font-size:13px;margin:6px 0 18px}}
table{{border-collapse:collapse;width:100%;background:#fff;font-size:13px}}
th,td{{border:1px solid #e3e7ed;padding:6px 8px;vertical-align:top}}
th{{background:#f3f6fa}} img{{width:420px;border:1px solid #dfe4ea;border-radius:4px}}
.ok{{color:#157347;font-weight:600}} .bad{{color:#b42318;font-weight:600}}
</style></head><body>"""]
    cls = "ok" if t["status"] == "success" else "bad"
    parts.append(f"<h1>{html.escape(t['task_id'])} <span class='{cls}'>{t['status']}</span></h1>")
    parts.append(f"<div class='meta'>app={html.escape(str(t.get('app')))} step={t['stats']['steps']} "
                 f"expected={html.escape(str(t.get('expected')))}</div>")
    parts.append("<table><tr><th>#</th><th>agent</th><th>action</th><th>pre</th><th>post</th><th>result</th></tr>")
    for s in t["steps"]:
        parts.append(
            f"<tr><td>{s['step_id']}</td><td>{html.escape(str(s.get('agent')))}</td>"
            f"<td>{html.escape(', '.join(x for x in s['action']['functions'] if x) or '-')}</td>"
            f"<td><img src='{html.escape(s['pre_img'])}'></td>"
            f"<td><img src='{html.escape(s['post_img'])}'></td>"
            f"<td>{html.escape(str(s.get('action_status')))}<br>{html.escape((s.get('result_text') or '')[:300])}</td></tr>")
    parts.append("</table></body></html>")
    Path(args.out).write_text("".join(parts), encoding="utf-8")
    print("wrote", args.out)


if __name__ == "__main__":
    main()
