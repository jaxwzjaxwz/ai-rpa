# 当前问题清单

> 按影响排序。标注“需确认”的，建议周一当面和王天宝对齐。

## 1. 本机没有 UFO 运行环境与 API Key（阻塞真实联合运行）

- 现象：`runner/run_case.py` 需要 Python 3.12 + UFO 依赖 + `model.local.json` 里的 key；
- 影响：只能跑**离线转换**，无法生成新的 UFO 运行日志；
- 需要：王天宝的 `ufo_baseline` 目录（或一份可用的 venv/依赖清单）与模型配置；
- 临时方案：先用仓库里 `examples/web_success/` 的原始日志跑通转换与检查（已完成）。

## 2. 仓库布局与 runner 预期不一致

- `runner/configure.py` 里 `REPO = ROOT.parent / "UFO"`，而仓库里 UFO 源码在 `src/ufo/`；
- 直接在本仓库根目录执行 `run_case.py` 会找不到 UFO；
- 需要：确认基座目录结构，或补一个 `--ufo-dir` 参数；
- 需确认：`src/ufo` 是否就是基座 `UFO` 目录的副本。

## 3. UFO 原始日志没有每步时间戳

- `response.log` 只有 `round_num` / `round_step` / `session_step`，没有绝对时间；
- 统一轨迹目前用步骤顺序，时间字段留空，只有整次运行的 `elapsed_seconds`；
- 可选修法：用 `console.log` 的时间行或截图文件 mtime 推断；需确认是否够用。

## 4. 只有成功样例，没有真实失败日志

- 仓库只提供 `examples/web_success/`；
- 检查器的失败判定已有单元测试（`accepted=false/503` → 不通过），但没有真实 `web_failure` 运行日志可转；
- 需要：王天宝补一份 `web_failure`（或 `file_failure`）的脱敏日志，格式同 success。

## 5. “前后截图”的语义是推断的

- 当前规则：第 N 步的 `clean_screenshot_path` = 动作前，第 N+1 步的截图 = 动作后；
- 样例人工核对成立（step3 表单已填、step4 成功页）；
- 需确认：UFO 是否在所有 case 下都先截图再执行，避免失败场景时序错位。

## 6. `request.log` 未入仓

- 样例里 `request.log` 3.4 MB，含完整 LLM 交互，未拉取（体积/脱敏）；
- 当前用 `response.log` 足够生成轨迹；
- 若要做“模型调用级”分析，需要脱敏后的 `request.log`。

## 7. 截图体积与脱敏

- 21 张原图约 2 MB，转成统一轨迹只复制 8 张；
- 后续每天新增运行，需要定一个保留策略（全留 / 只留关键步 / 压 JPEG）。
