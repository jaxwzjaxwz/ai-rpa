# 运行说明（2026.11.20）

## 0. 目录

```
2026.11.20/
├─ inputs/web_success/     # 从团队仓库拉取的 UFO 原始运行证据（manifest/result/response.log/截图/后端事件）
├─ trajectory/             # 统一轨迹：schema + 转换器
├─ checker/                # 独立结果检查器
├─ tests/test_checker.py   # 检查器正/负例测试
├─ pipeline.py             # 离线联合流程：转换 → 检查 → 汇总
├─ run_live.py             # 实跑封装：调用 runner/run_case.py 后再转换+检查
├─ make_viewer.py          # 生成轨迹回看页
└─ runs/web_success_example/  # 本次产物
```

## 1. 离线联合运行（已跑通，无需 API Key）

```powershell
cd "C:\Users\shhbi\Desktop\Computer Vision\2026.11.20"

# 转换 + 独立检查 + 汇总
C:\Users\shhbi\Desktop\Computer Vision\.venv\Scripts\python.exe pipeline.py `
  --run-dir inputs\web_success --out runs\web_success_example

# 可选：生成回看页
C:\Users\shhbi\Desktop\Computer Vision\.venv\Scripts\python.exe make_viewer.py `
  --trajectory runs\web_success_example\trajectory.json `
  --out runs\web_success_example\viewer.html
```

预期输出：

```json
{
  "task_id": "20261113_215341_131065_web_success",
  "ufo_status": "task_succeeded",
  "ufo_task_success": true,
  "check_passed": true,
  "consistent": true,
  "steps": 4,
  "screenshots": 8
}
```

## 2. 分开跑

```powershell
# 只做转换
..\.venv\Scripts\python.exe trajectory\convert_ufo.py --run-dir inputs\web_success --out runs\web_success_example

# 只做检查
..\.venv\Scripts\python.exe checker\web_submit.py runs\web_success_example
```

## 3. 测试

```powershell
..\.venv\Scripts\python.exe tests\test_checker.py
```

预期：

```
PASS case: checker passed = True
FAIL case: checker passed = False http = None
all checker tests passed
```

## 4. 联合运行（真实 UFO，需要基座环境）

前提（由王天宝提供）：

- Windows + Python 3.12；
- 按 `README.md` 装好 `requirements-lock.txt` 与 `src/ufo/requirements.txt`；
- `runner/model.local.json` 填好 API Key；
- `runner/configure.py` 能找到 UFO 源码目录。

命令：

```powershell
..\.venv\Scripts\python.exe run_live.py `
  --runner-dir "D:\wtb\ufo_baseline\runner" `
  --case web_success `
  --out runs\live_web_success
```

流程：`run_case.py` 启动 UFO → 产出 `runs/<run_id>/`（response.log + 截图 + result.json）→ 本仓库的转换器与检查器接管。

> 当前机器没有 UFO 环境与 API Key，这一步**未实跑**，代码已就绪。

## 5. 产物说明

| 文件 | 内容 |
|---|---|
| `runs/<case>/trajectory.json` | 统一轨迹（任务号、步骤、动作、前后截图、结果） |
| `runs/<case>/steps.csv` | 一行一步，便于人工核对 |
| `runs/<case>/check.json` | 独立检查证据 |
| `runs/<case>/summary.json` | 汇总（UFO 结论 vs 独立检查是否一致） |
| `runs/<case>/viewer.html` | 前后截图对照页 |
