"""Offline joint pipeline: UFO raw logs -> unified trajectory -> independent check.

Usage:
    python pipeline.py --run-dir inputs/web_success --out runs/web_success_example
"""
import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from trajectory.convert_ufo import convert  # noqa: E402
from checker.web_submit import check  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", required=True, help="directory containing manifest.json / response.log")
    ap.add_argument("--out", required=True, help="output directory")
    args = ap.parse_args()

    run_dir, out = Path(args.run_dir), Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    trajectory = convert(run_dir, out)
    check_result = check(run_dir)

    ufo_success = trajectory["outcome"]["task_success"]
    consistent = (bool(check_result["passed"]) == bool(ufo_success))

    summary = {
        "task_id": trajectory["task_id"],
        "case": trajectory["case"],
        "source": "ufo",
        "expected": trajectory["expected"],
        "ufo_status": trajectory["outcome"]["status"],
        "ufo_task_success": ufo_success,
        "check_passed": check_result["passed"],
        "consistent": consistent,
        "steps": trajectory["stats"]["steps"],
        "screenshots": trajectory["stats"]["screenshots"],
        "artifacts": {
            "trajectory": str(out / "trajectory.json"),
            "check": str(out / "check.json"),
            "steps_csv": str(out / "steps.csv"),
            "screenshots": str(out / "screenshots"),
        },
    }
    (out / "check.json").write_text(json.dumps(check_result, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if consistent else 1


if __name__ == "__main__":
    raise SystemExit(main())
