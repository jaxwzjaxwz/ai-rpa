"""Live joint run: let runner/run_case.py drive real UFO, then convert + check.

Requires the baseline environment (Python 3.12, UFO installed, model.local.json with a key).
This wrapper does not modify UFO internals.

Usage:
    python run_live.py --runner-dir ..\ai-rpa\runner --case web_success --out runs\live_web_success
"""
import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from trajectory.convert_ufo import convert  # noqa: E402
from checker.web_submit import check  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runner-dir", required=True, help="directory containing run_case.py")
    ap.add_argument("--case", default="web_success")
    ap.add_argument("--timeout", type=int, default=600)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    runner_dir = Path(args.runner_dir).resolve()
    cmd = [sys.executable, "run_case.py", args.case, "--timeout", str(args.timeout)]
    print("$", " ".join(cmd), "(cwd=%s)" % runner_dir)
    proc = subprocess.run(cmd, cwd=runner_dir, text=True, capture_output=True)
    print(proc.stdout)
    if proc.returncode != 0:
        print(proc.stderr, file=sys.stderr)
        return proc.returncode

    m = re.search(r"Run artifacts:\s*(.+)", proc.stdout)
    if not m:
        print("cannot locate run directory from runner output", file=sys.stderr)
        return 2
    run_dir = Path(m.group(1).strip())
    print("run dir:", run_dir)

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    trajectory = convert(run_dir, out)
    check_result = check(run_dir)
    summary = {
        "task_id": trajectory["task_id"],
        "mode": "live",
        "expected": trajectory["expected"],
        "ufo_status": trajectory["outcome"]["status"],
        "ufo_task_success": trajectory["outcome"]["task_success"],
        "check_passed": check_result["passed"],
        "consistent": bool(check_result["passed"]) == bool(trajectory["outcome"]["task_success"]),
        "steps": trajectory["stats"]["steps"],
        "artifacts": {"trajectory": str(out / "trajectory.json"), "check": str(out / "check.json")},
    }
    (out / "check.json").write_text(json.dumps(check_result, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
