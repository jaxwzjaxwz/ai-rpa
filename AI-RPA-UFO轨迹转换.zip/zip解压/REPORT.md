# 本周结果报告（2026-11-20）

## 一、任务

按 11-17 的组内安排：

1. 把王天宝提供的 UFO 原始执行日志转换成**统一轨迹格式**（任务编号、操作步骤、前后截图、执行结果）；
2. 打通一条**网页提交**的联合流程：UFO 执行 → 独立检查实际提交结果 → 保存完整轨迹；
3. 周一验收：实际运行结果、代码、日志；交付仓库地址、运行说明、测试结果、问题清单。

## 二、完成情况

| 事项 | 状态 | 证据 |
|---|---|---|
| UFO 原始日志 → 统一轨迹 | ✅ 完成 | `runs/web_success_example/trajectory.json`（4 步、8 张图） |
| 独立网页提交检查 | ✅ 完成 | `runs/web_success_example/check.json`（accepted=true, HTTP 200） |
| 转换 + 检查串联 | ✅ 完成 | `summary.json`：`consistent=true` |
| 检查器正/负例测试 | ✅ 完成 | `tests/test_checker.py` 全部通过 |
| 轨迹回看页 | ✅ 完成 | `runs/web_success_example/viewer.html` |
| 真实 UFO 联合运行 | ⏳ 未执行 | 本机无 UFO 环境与 API Key；`run_live.py` 已就绪 |
| 失败场景实跑 | ⏳ 未执行 | 需先有 web_failure 的真实运行日志 |

## 三、数据来源

团队仓库 `examples/web_success/`（脱敏样例）：

- 运行编号：`20261113_215341_131065_web_success`
- 模型：阿里云百炼 `qwen3-vl-plus`
- 原始文件：`manifest.json`、`result.json`、`response.log`（6 条）、`screenshots/`（21 张）、`server_events.jsonl`、`accepted_submissions.jsonl`

## 四、结果

| 指标 | 值 |
|---|---|
| 统一轨迹步数 | 4（2 次输入 + 1 次点击 + 1 次 FINISH） |
| 截图 | 8 张（每步前/后各一） |
| UFO 自报结果 | `task_succeeded`，退出码 0，耗时 279 秒 |
| 独立检查 | 通过：收到 1 次匹配字段的 POST，`accepted=true`，HTTP 200 |
| 两者一致性 | ✅ 一致 |

轨迹示例（第 3 步）：

```json
{
  "step_id": 3,
  "agent": "AppAgent",
  "application": "msedge.exe",
  "action": {"functions": ["click_input"], "calls": ["click_input(id='25', name='Submit', button='left', double=False)"]},
  "action_status": "success",
  "pre_img": "screenshots/step_0003_pre.png",
  "post_img": "screenshots/step_0003_post.png"
}
```

- 前截图：表单已填好、尚未提交；
- 后截图：`Submission successful / Your data was saved.`。

## 五、字段映射（UFO → 统一）

| UFO | 统一 |
|---|---|
| `manifest.run_id` | `task_id` |
| `clean_screenshot_path` | `pre_img` |
| 下一步截图 / `action_step_final.png` | `post_img` |
| `action[].function` | `action.functions` |
| `action_success[0].result.status` | `action_status` |
| `result` | `result_text` |
| `result.task_success` | `status` / `outcome.task_success` |

## 六、结论

- 离线转换链路已打通，字段能一一对应；
- 独立检查不依赖 UFO 自报，能验证“后端真的收到了匹配的提交”；
- 距离“可复现的联合运行”只差**基座环境 + API Key**。

## 七、已知问题

见 `PROBLEMS.md`（共 6 条，含基座环境缺失、日志无时间戳、失败样例缺失等）。
