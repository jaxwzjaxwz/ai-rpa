# GUI 操作轨迹采集（AI-RPA 项目）

> 2026-11-15 起的新任务：负责 GUI 操作轨迹采集与模型评测。
> 参考：[OmegaUse-SOP](https://github.com/baidu-frontier-research/omegause-sop)（Baidu，EMNLP 2026 demo）
> 目标：一周内交付「轨迹记录模块 + 数据格式 + 真实轨迹 + 运行结果」。

---

## 1. 这个模块解决什么问题

GUI Agent 要学会“专业软件的标准操作流程（SOP）”，第一步是**把人的操作录下来**。
我们做一个轻量版采集器，每个动作保存：

- 操作**前**截图
- 执行的动作（点击坐标 / 按键 / 输入）
- 操作**后**截图
- 时间戳
- 任务编号
- 执行结果（成功 / 失败 / 原因）

并且能把一个完整任务**存下来、重新读出来**，供后续训练/评测使用。

---

## 2. 与 OmegaUse-SOP 的对应关系

| OmegaUse-SOP | 本模块 | 说明 |
|---|---|---|
| `screenshots/`（操作前截图） | `screenshots/NNNN_pre.png` | 一致 |
| `recording.json`（低层事件） | `steps.jsonl`（一行一个动作） | 结构兼容，字段更少 |
| `clicked_boxes/`（UI 元素裁剪） | 暂不做 | 需要 OmniParser/PaddleOCR，后续可加 |
| `prompt.json`（VLM 语义指令） | 暂不做 | 属于 Reason 阶段 |
| `domain.md` / `params.md` | `meta.json` 里预留 `params` | 后续扩展 |
| `replay_logs/` | `outcome.json` | 记录任务级结果 |

结论：**只复刻 Observe 层**，字段留好扩展位，以后能直接转成 OmegaUse-SOP 的输入。

---

## 3. 目录结构

```
2026.11.15/
├── README.md                  # 本文件
├── PLAN.md                    # 两天排期
├── DATA_FORMAT.md             # 数据格式说明
├── schema.json                # 机器可读的 schema
├── trajectory_recorder/
│   ├── recorder.py            # 核心：Recorder 类
│   ├── loader.py              # 读取 / 校验 / 汇总
│   └── screenshot.py          # 截图 + DPI 处理
├── tasks/
│   ├── base.py                # 任务适配器接口
│   └── checks.py              # 结果校验器（文件、HTTP、文本）
├── demo_episode.py            # 不依赖 GUI 的端到端自测
├── viewer.html                # （待做）前后截图对照查看器
└── episodes/                  # 采集输出
    └── web_submit_0001/
        ├── meta.json
        ├── steps.jsonl
        ├── outcome.json
        └── screenshots/
            ├── 0001_pre.png
            └── 0001_post.png
```

---

## 4. 快速开始

```powershell
cd "C:\Users\shhbi\Desktop\Computer Vision\2026.11.15"

# 自测：不需要 GUI，验证“写入-读取-校验”闭环
..\.venv\Scripts\python.exe demo_episode.py

# 真实采集：接入易木的任务后，用 tasks\base.py 的 TaskAdapter 包一层再跑
# （入口待易木提供，见第 6 节）
```

在易木的脚本里接入只需要三行：

```python
from trajectory_recorder.recorder import Recorder

rec = Recorder(task_id="file_save_0001", task_name="保存文件", app="notepad")
rec.start()
with rec.action("click", target={"elem_text": "保存"}) as step:
    do_click()                       # 你的动作
    step["result"] = "ok"            # 可选：写结果
rec.finish(status="success", outcome={"checker": "文件存在且内容一致"})
```

---

## 5. 当前状态

| 项 | 状态 |
|---|---|
| 截图（多屏、DPI） | ✅ 已验证（本机 3072×1920） |
| Recorder（前后截图 + JSONL） | ✅ 已实现 |
| Loader（读取 + 校验 + 汇总） | ✅ 已实现 |
| Schema / 数据格式文档 | ✅ 已实现 |
| 任务适配器接口 + 校验器 | ✅ 已实现 |
| 替身任务（文件保存 + 表单提交） | ✅ 已实现（Tk 窗口） |
| **真实轨迹采集** | ✅ **12 条（6 成功 + 6 失败）** |
| summary.csv / REPORT.md | ✅ 已生成 |
| viewer.html 前后图对照 | ✅ 已生成 |
| 接入易木的文件保存 / 网页提交 | ⏳ 待接口 |
| VLM 结果判定 | ⏳ 可选 |
| 全局键鼠钩子 | ⏳ 兜底方案，未做 |

---

## 6. 下一步（需要确认）

1. 易木两个任务的入口（脚本路径 / 网页 URL）；
2. 是否有可用 VLM API（Qwen-VL / GPT-4o）；
3. 采集用哪台机器、屏幕缩放比例（本机是 3072×1920）。
