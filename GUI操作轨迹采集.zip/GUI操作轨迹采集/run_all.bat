@echo off
chcp 65001 >nul
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"

set "PY=.venv\Scripts\python.exe"
if not exist "%PY%" set "PY=..\.venv\Scripts\python.exe"
if not exist "%PY%" set "PY=python"

"%PY%" -c "import PIL" >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Pillow is missing.
    echo Run setup.bat first, or:
    echo     %PY% -m pip install -r requirements.txt
    pause
    exit /b 1
)

echo ==============================
echo  Step 1/3  self-test ^(demo^)
echo ==============================
"%PY%" demo_episode.py
if errorlevel 1 goto :err

echo.
echo ==============================
echo  Step 2/3  collect 12 episodes
echo  windows will pop up, do not touch mouse
echo ==============================
"%PY%" collect.py
if errorlevel 1 goto :err

echo.
echo ==============================
echo  Step 3/3  build summary/report
echo ==============================
"%PY%" make_report.py
if errorlevel 1 goto :err

echo.
echo Done. Opening viewer.html ...
start "" "viewer.html"
pause
goto :eof

:err
echo.
echo [FAILED] see error above.
pause
