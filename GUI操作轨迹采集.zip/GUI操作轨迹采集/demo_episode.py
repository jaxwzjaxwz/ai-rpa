"""不依赖 GUI 的端到端自测：写入一条 3 步轨迹 → 重新读取 → 校验。

运行：
    ..\\.venv\\Scripts\\python.exe demo_episode.py
"""
import shutil
import sys
from pathlib import Path

from PIL import Image, ImageDraw

from trajectory_recorder import Recorder, load_episode, list_episodes

ROOT = Path(__file__).parent / "episodes"
TASK_ID = "demo_episode_0001"


def fake_capture(path):
    """用纯色图代替真实截图，保证在无桌面环境下也能测。"""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    img = Image.new("RGB", (800, 450), (245, 247, 250))
    d = ImageDraw.Draw(img)
    d.text((30, 30), f"FAKE SCREENSHOT\n{path.name}", fill=(30, 30, 30))
    img.save(path, "PNG")
    return img.size


def main():
    ep_dir = ROOT / TASK_ID
    if ep_dir.exists():
        shutil.rmtree(ep_dir)

    rec = Recorder(TASK_ID, "演示任务：三步操作", out_root=ROOT,
                   operator="haonan", app="demo", capture=fake_capture)
    rec.start()

    with rec.action("open", target={"app": "notepad"}) as s:
        s["note"] = "打开记事本"

    with rec.action("type", text="hello world", target={"elem": "edit"}) as s:
        s["note"] = "输入文本"

    try:
        with rec.action("click", target={"elem_text": "保存"}) as s:
            s["note"] = "点击保存"
            s["result"] = "ok"
    except Exception:
        pass

    rec.finish(status="success", outcome={"checker": "文件已生成", "passed": True})

    ep = load_episode(ep_dir)
    print(f"目录: {ep['dir']}")
    print(f"任务: {ep['meta']['task_name']}  状态: {ep['meta']['status']}  步数: {len(ep['steps'])}")
    print(f"校验错误: {ep['errors'] or '无'}")
    for row in list_episodes(ROOT):
        print("  ", row)

    if ep["errors"]:
        sys.exit(1)
    print("OK: 写入-读取-校验 闭环通过")


if __name__ == "__main__":
    main()
