"""截图工具：处理 Windows DPI 缩放，统一抓物理像素。"""
import ctypes
from pathlib import Path

from PIL import ImageGrab


def enable_dpi_awareness() -> None:
    """让进程感知 DPI，避免 150%/200% 缩放下截图被二次缩放。"""
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)  # PER_MONITOR_AWARE
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


enable_dpi_awareness()


def grab():
    """抓取所有屏幕的拼接图。"""
    return ImageGrab.grab(all_screens=True)


def capture_to(path) -> tuple:
    """截图并保存，返回 (宽, 高)。"""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    img = grab()
    img.save(path, "PNG")
    return img.size
