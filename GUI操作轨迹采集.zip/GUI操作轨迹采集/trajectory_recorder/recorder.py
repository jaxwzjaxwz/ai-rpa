"""轨迹记录核心：每个动作保存「前截图 + 动作 + 后截图 + 时间 + 结果」。

用法：
    rec = Recorder(task_id="file_save_0001", task_name="保存文件", app="notepad")
    rec.start()
    with rec.action("click", target={"elem_text": "保存"}) as step:
        do_click()
        step["result"] = "ok"
    rec.finish(status="success", outcome={"checker": "文件存在"})
"""
import json
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

from .screenshot import capture_to


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="milliseconds")


class Recorder:
    def __init__(self, task_id, task_name, out_root="episodes", operator="",
                 app="", params=None, post_delay=0.25, capture=None):
        self.task_id = task_id
        self.task_name = task_name
        self.out_root = Path(out_root)
        self.operator = operator
        self.app = app
        self.params = params or {}
        self.post_delay = post_delay
        self._capture = capture or capture_to

        self.dir = self.out_root / task_id
        self._steps_path = self.dir / "steps.jsonl"
        self._fh = None
        self._n = 0
        self._started = False
        self._finished = False
        self.meta = {}

    # ---------- 生命周期 ----------
    def start(self):
        if self._started:
            return self
        (self.dir / "screenshots").mkdir(parents=True, exist_ok=True)
        self.meta = {
            "task_id": self.task_id,
            "task_name": self.task_name,
            "operator": self.operator,
            "app": self.app,
            "params": self.params,
            "started_at": now_iso(),
            "ended_at": None,
            "status": "running",
            "env": {"os": "Windows", "python": "3.12+", "platform": "desktop"},
        }
        self._write_json(self.dir / "meta.json", self.meta)
        self._fh = open(self._steps_path, "a", encoding="utf-8")
        self._started = True
        return self

    def finish(self, status="success", outcome=None):
        if not self._started or self._finished:
            return
        self._finished = True
        if self._fh:
            self._fh.close()
        self.meta["ended_at"] = now_iso()
        self.meta["status"] = status
        self._write_json(self.dir / "meta.json", self.meta)
        self._write_json(self.dir / "outcome.json", {
            "task_id": self.task_id,
            "status": status,
            "checked_at": now_iso(),
            "outcome": outcome or {},
        })

    def __enter__(self):
        return self.start()

    def __exit__(self, exc_type, exc, tb):
        if exc_type is not None:
            self.finish("aborted", {"error": f"{exc_type.__name__}: {exc}"})
        else:
            self.finish("success")
        return False

    # ---------- 记录 ----------
    @contextmanager
    def action(self, action_type, target=None, note="", result="ok", **params):
        """记录一个动作：进入时截“前”图，退出时截“后”图并落盘。"""
        if not self._started:
            self.start()
        self._n += 1
        step = {
            "step_id": self._n,
            "action": {"type": action_type, **params},
            "target": target or {},
            "ts_before": now_iso(),
            "result": result,
            "note": note,
        }
        step["pre_img"], _ = self._shot(f"{self._n:04d}_pre")
        t0 = time.perf_counter()
        try:
            yield step
        except Exception as e:
            step["result"] = "error"
            step["error"] = f"{type(e).__name__}: {e}"
            raise
        finally:
            time.sleep(self.post_delay)
            step["duration_ms"] = round((time.perf_counter() - t0) * 1000)
            step["ts_after"] = now_iso()
            step["post_img"], _ = self._shot(f"{self._n:04d}_post")
            self._write_step(step)

    def snapshot(self, label, note=""):
        """手动打点：不包动作，只截一张图。"""
        if not self._started:
            self.start()
        rel, size = self._shot(f"snap_{label}")
        return {"img": rel, "size": size, "ts": now_iso(), "note": note}

    # ---------- 内部 ----------
    def _shot(self, stem):
        path = self.dir / "screenshots" / f"{stem}.png"
        size = self._capture(path)
        return str(path.relative_to(self.dir)).replace("\\", "/"), size

    def _write_step(self, step):
        self._fh.write(json.dumps(step, ensure_ascii=False) + "\n")
        self._fh.flush()

    @staticmethod
    def _write_json(path, obj):
        Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
