"""读取 / 校验 / 汇总轨迹。"""
import json
import sys
from datetime import datetime
from pathlib import Path

REQUIRED_META = ["task_id", "task_name", "started_at", "status"]
REQUIRED_STEP = ["step_id", "action", "ts_before", "pre_img", "post_img", "result"]


def load_episode(ep_dir, check_files=True):
    ep = Path(ep_dir)
    meta = json.loads((ep / "meta.json").read_text(encoding="utf-8"))
    steps = [json.loads(line) for line in
             (ep / "steps.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
    outcome = {}
    if (ep / "outcome.json").exists():
        outcome = json.loads((ep / "outcome.json").read_text(encoding="utf-8"))
    errors = validate(meta, steps, ep if check_files else None)
    return {"dir": str(ep), "meta": meta, "steps": steps, "outcome": outcome, "errors": errors}


def validate(meta, steps, ep=None):
    errors = []
    for key in REQUIRED_META:
        if key not in meta:
            errors.append(f"meta 缺字段: {key}")
    for i, step in enumerate(steps, 1):
        for key in REQUIRED_STEP:
            if key not in step:
                errors.append(f"step {i} 缺字段: {key}")
        if "type" not in step.get("action", {}):
            errors.append(f"step {i} 缺 action.type")
        if ep is not None:
            for key in ("pre_img", "post_img"):
                rel = step.get(key)
                if rel and not (ep / rel).exists():
                    errors.append(f"step {i} 图片不存在: {rel}")
    return errors


def _duration_s(meta):
    try:
        t0 = datetime.fromisoformat(meta["started_at"])
        t1 = datetime.fromisoformat(meta["ended_at"]) if meta.get("ended_at") else t0
        return round((t1 - t0).total_seconds(), 1)
    except Exception:
        return None


def list_episodes(root="episodes"):
    rows = []
    for meta_path in sorted(Path(root).glob("*/meta.json")):
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            n = sum(1 for line in (meta_path.parent / "steps.jsonl").read_text(encoding="utf-8").splitlines() if line.strip())
            rows.append({
                "task_id": meta.get("task_id"),
                "task_name": meta.get("task_name"),
                "status": meta.get("status"),
                "steps": n,
                "duration_s": _duration_s(meta),
                "started_at": meta.get("started_at"),
            })
        except Exception as e:
            rows.append({"task_id": meta_path.parent.name, "error": str(e)})
    return rows


def main():
    root = sys.argv[1] if len(sys.argv) > 1 else "episodes"
    rows = list_episodes(root)
    if not rows:
        print(f"没有找到轨迹: {root}")
        return
    print(f"{'task_id':<24}{'status':<10}{'steps':<7}{'sec':<8}task_name")
    for r in rows:
        print(f"{str(r.get('task_id')):<24}{str(r.get('status')):<10}{str(r.get('steps')):<7}{str(r.get('duration_s')):<8}{r.get('task_name', '')}")
    print(f"\n共 {len(rows)} 条轨迹")


if __name__ == "__main__":
    main()
