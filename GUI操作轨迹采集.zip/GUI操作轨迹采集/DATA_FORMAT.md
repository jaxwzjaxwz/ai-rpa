# 数据格式说明（v0）

一个任务 = 一个目录，目录名就是 `task_id`。

```
episodes/
└── web_submit_0001/
    ├── meta.json          # 任务级信息
    ├── steps.jsonl        # 动作级信息，一行一个
    ├── outcome.json       # 任务结果
    └── screenshots/
        ├── 0001_pre.png
        ├── 0001_post.png
        └── ...
```

---

## 1. meta.json

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `task_id` | string | ✅ | 任务编号，与目录名一致，如 `file_save_0001` |
| `task_name` | string | ✅ | 任务名，如“保存文件到桌面” |
| `operator` | string | | 操作人 |
| `app` | string | | 目标应用，如 `chrome` / `notepad` |
| `params` | object | | 任务参数（预留，对应 OmegaUse-SOP 的 `params.md`） |
| `started_at` | ISO8601 | ✅ | 开始时间，带时区 |
| `ended_at` | ISO8601 | | 结束时间 |
| `status` | enum | ✅ | `running` / `success` / `failed` / `aborted` |
| `env` | object | | 环境信息（OS、屏幕、缩放） |

示例：

```json
{
  "task_id": "file_save_0001",
  "task_name": "把结果保存到桌面",
  "operator": "haonan",
  "app": "notepad",
  "params": {"save_path": "C:/Users/shhbi/Desktop/out.txt"},
  "started_at": "2026-11-15T15:02:10.120+08:00",
  "ended_at": "2026-11-15T15:02:31.884+08:00",
  "status": "success",
  "env": {"os": "Windows 11", "screen": [3072, 1920], "dpi": 200}
}
```

---

## 2. steps.jsonl

每行一个 JSON，字段如下：

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `step_id` | int | ✅ | 从 1 递增 |
| `action` | object | ✅ | 至少含 `type`；`click` 带 `x,y`，`type` 带 `text`，`key` 带 `key` |
| `target` | object | | 目标元素：`window` / `title` / `elem_text` / `bbox` |
| `ts_before` | ISO8601 | ✅ | 动作开始时间 |
| `ts_after` | ISO8601 | | 动作结束时间 |
| `duration_ms` | number | | 动作耗时 |
| `pre_img` | string | ✅ | 相对路径，如 `screenshots/0001_pre.png` |
| `post_img` | string | ✅ | 相对路径 |
| `result` | enum | ✅ | `ok` / `error` / `unknown` |
| `note` | string | | 人工备注 |
| `error` | string | | 异常信息（`result=error` 时） |

示例：

```json
{"step_id": 1, "action": {"type": "click", "x": 812, "y": 446, "button": "left"},
 "target": {"window": "Chrome", "title": "报名表", "elem_text": "提交"},
 "ts_before": "2026-11-15T15:02:11.231+08:00", "ts_after": "2026-11-15T15:02:12.004+08:00",
 "duration_ms": 773, "pre_img": "screenshots/0001_pre.png", "post_img": "screenshots/0001_post.png",
 "result": "ok", "note": "点击后出现提交成功提示"}
```

---

## 3. outcome.json

| 字段 | 类型 | 说明 |
|---|---|---|
| `task_id` | string | 任务编号 |
| `status` | enum | `success` / `failed` / `aborted` |
| `checked_at` | ISO8601 | 判定时间 |
| `outcome.passed` | bool | 校验器结论 |
| `outcome.evidence` | object | 证据（文件路径、HTTP 状态、文本命中） |
| `outcome.vlm_judge` | object | 可选：VLM 判定 `{verdict, confidence, model}` |
| `outcome.agree_with_label` | bool | 可选：VLM 与人工标签是否一致 |

示例：

```json
{
  "task_id": "file_save_0001",
  "status": "success",
  "checked_at": "2026-11-15T15:02:32.001+08:00",
  "outcome": {
    "passed": true,
    "evidence": {"path": "C:/Users/shhbi/Desktop/out.txt", "size": 128},
    "vlm_judge": {"verdict": "success", "confidence": 0.92, "model": "qwen3-vl"},
    "agree_with_label": true
  }
}
```

---

## 4. 命名与校验规则

- `task_id` 建议格式：`{任务类型}_{序号}`，如 `file_save_0001`、`web_submit_0003`；
- 序号从 `0001` 开始，成功/失败都占号；
- 校验器会检查：必填字段、图片文件是否存在；
- 图片统一 PNG，`all_screens=True` 抓全部屏幕，坐标一律用物理像素。

## 5. 体积估算

| 项 | 单步大小 | 说明 |
|---|---|---|
| 前后两张 PNG（3072×1920） | 约 1.5–3 MB | 取决于画面复杂度 |
| 一个 10 步任务 | 约 15–30 MB | 100 条任务约 2–3 GB |

建议：采集时保留原图，长期存档可转 JPEG（质量 85）压缩到 1/5。

## 6. 与 OmegaUse-SOP 的映射

| 本格式 | OmegaUse-SOP |
|---|---|
| `screenshots/*_pre.png` | `screenshots/` |
| `steps.jsonl` | `recording.json` 的事件列表 |
| `target.elem_text` / `bbox` | `clicked_boxes/`（需 OmniParser） |
| `meta.params` | `params.md` |
| `outcome.json` | `replay_logs/` + 验证结果 |
