"""采集替身任务的真实轨迹：文件保存 + 表单提交，各 3 成功 + 3 失败。

运行：
    ..\\.venv\\Scripts\\python.exe collect.py
"""
import shutil
from pathlib import Path

import tkinter as tk

from tasks.demo_app import DemoApp, window_capture
from trajectory_recorder import Recorder

BASE = Path(__file__).parent
OUT = BASE / "episodes"
SANDBOX = BASE / "sandbox"
N = 3


def run_file_save(idx, ok):
    workdir = SANDBOX / "file_save"
    root = tk.Tk()
    app = DemoApp(root, workdir)
    rec = Recorder(f"file_save_{idx:04d}", "保存文本到文件", out_root=OUT,
                   operator="haonan", app="demo_app", capture=window_capture(root))
    rec.start()

    content = f"hello trajectory {idx}"
    target = workdir / f"out_{idx}.txt" if ok else Path("Z:/no_such_dir") / f"out_{idx}.txt"

    with rec.action("type", text=content, target={"elem": "text"}) as s:
        app.text_var.set(content)
        app.path_var.set(str(target))
        root.update()
        s["note"] = "填入内容与保存路径"

    with rec.action("click", target={"elem_text": "保存文件"}) as s:
        app.save_btn.invoke()
        root.update()
        s["note"] = app.status_var.get()
        s["result"] = "ok" if app.last["ok"] else "error"

    passed = bool(app.last["ok"]) and Path(target).exists()
    rec.finish("success" if passed else "failed",
               {"passed": passed, "evidence": {"path": str(target), "detail": app.last["detail"]}})
    root.destroy()
    return passed


def run_web_submit(idx, ok):
    workdir = SANDBOX / "web"
    root = tk.Tk()
    app = DemoApp(root, workdir)
    rec = Recorder(f"web_submit_{idx:04d}", "填写并提交表单", out_root=OUT,
                   operator="haonan", app="demo_app", capture=window_capture(root))
    rec.start()

    name = f"user{idx}"
    email = f"user{idx}@example.com" if ok else f"user{idx}example.com"  # 缺 @，触发失败

    with rec.action("type", text=name, target={"elem": "name"}) as s:
        app.name_var.set(name)
        root.update()

    with rec.action("type", text=email, target={"elem": "email"}) as s:
        app.email_var.set(email)
        root.update()

    with rec.action("click", target={"elem_text": "提交表单"}) as s:
        app.submit_btn.invoke()
        root.update()
        s["note"] = app.form_status_var.get()
        s["result"] = "ok" if app.last["ok"] else "error"

    passed = bool(app.last["ok"])
    rec.finish("success" if passed else "failed",
               {"passed": passed, "evidence": {"detail": app.last["detail"]}})
    root.destroy()
    return passed


def main():
    if OUT.exists():
        shutil.rmtree(OUT)
    if SANDBOX.exists():
        shutil.rmtree(SANDBOX)
    OUT.mkdir(parents=True, exist_ok=True)
    SANDBOX.mkdir(parents=True, exist_ok=True)

    results = []
    for i in range(1, N + 1):
        results.append(("file_save", i, True, run_file_save(i, True)))
    for i in range(N + 1, 2 * N + 1):
        results.append(("file_save", i, False, run_file_save(i, False)))
    for i in range(1, N + 1):
        results.append(("web_submit", i, True, run_web_submit(i, True)))
    for i in range(N + 1, 2 * N + 1):
        results.append(("web_submit", i, False, run_web_submit(i, False)))

    print(f"{'任务':<16}{'编号':<6}{'期望':<6}{'实际通过'}")
    for kind, idx, expect, passed in results:
        print(f"{kind:<16}{idx:<6}{str(expect):<6}{passed}")

    n_ok = sum(1 for *_, p in results if p)
    print(f"\n共 {len(results)} 条轨迹，成功 {n_ok} 条，失败 {len(results) - n_ok} 条")
    print(f"输出目录: {OUT}")


if __name__ == "__main__":
    main()
