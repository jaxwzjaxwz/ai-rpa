# 轨迹采集结果报告

- 轨迹数量：12 条（成功 6 条，失败 6 条）
- 总步数：30 步，平均每条 2.5 步
- 平均耗时：1.03 秒/条
- 截图：60 张，合计 2.0 MB
- 任务类型：文件保存、表单提交（替身任务，等待接入易木真实任务）
- 每条轨迹：2–3 个动作，每个动作前后各一张截图（只截应用窗口）

## 汇总

| 任务编号 | 任务 | 状态 | 步数 | 耗时(s) | 校验通过 |
| --- | --- | --- | --- | --- | --- |
| file_save_0001 | 保存文本到文件 | success | 2 | 0.89 | True |
| file_save_0002 | 保存文本到文件 | success | 2 | 0.83 | True |
| file_save_0003 | 保存文本到文件 | success | 2 | 0.87 | True |
| file_save_0004 | 保存文本到文件 | failed | 2 | 0.85 | False |
| file_save_0005 | 保存文本到文件 | failed | 2 | 0.85 | False |
| file_save_0006 | 保存文本到文件 | failed | 2 | 0.85 | False |
| web_submit_0001 | 填写并提交表单 | success | 3 | 1.19 | True |
| web_submit_0002 | 填写并提交表单 | success | 3 | 1.2 | True |
| web_submit_0003 | 填写并提交表单 | success | 3 | 1.18 | True |
| web_submit_0004 | 填写并提交表单 | failed | 3 | 1.23 | False |
| web_submit_0005 | 填写并提交表单 | failed | 3 | 1.24 | False |
| web_submit_0006 | 填写并提交表单 | failed | 3 | 1.2 | False |

## 失败样本怎么造

- 文件保存：保存路径设为不存在的盘符 `Z:/no_such_dir/...`，写入抛 `FileNotFoundError`；
- 表单提交：邮箱填成 `user4example.com`（缺 `@`），界面提示“邮箱格式错误”。

## 校验方式

- 文件保存：检查目标文件是否真的生成；
- 表单提交：检查界面状态“提交成功”，并核对 `sandbox/web/submissions.csv`。

## 复现

```powershell
cd "C:\Users\shhbi\Desktop\Computer Vision\2026.11.15"
..\.venv\Scripts\python.exe collect.py
..\.venv\Scripts\python.exe make_report.py
```


## VLM 结果判定

- 状态：**未执行**（环境无 VLM_API_KEY / OPENAI_API_KEY）
- 接口已就绪（`vlm_judge.py`），配置 key 后执行：
  ```powershell
  set VLM_API_KEY=...
  ..\.venv\Scripts\python.exe vlm_judge.py --all
  ```

## 任务要求对照

| 要求 | 交付物 | 状态 |
| --- | --- | --- |
| 操作前截图 | `steps.jsonl` 的 `pre_img` | ✅ |
| 执行动作 | `steps.jsonl` 的 `action` | ✅ |
| 操作后截图 | `steps.jsonl` 的 `post_img` | ✅ |
| 时间 | `ts_before` / `ts_after` / `duration_ms` | ✅ |
| 任务编号 | `meta.json` 的 `task_id` | ✅ |
| 执行结果 | `outcome.json` 的 `status` + `passed` | ✅ |
| 完整任务保存并重新读取 | `Recorder` + `load_episode` | ✅ |
| 正常 + 失败两类轨迹 | 各 6 条 | ✅ |
| 接入易木任务 | — | ⏳ 按要求暂缓 |
| VLM 判定 | `vlm_judge.py` | ⏳ 无 key，接口就绪 |

## 局限

1. 目前是替身任务（Tk 窗口），不是易木的文件保存/网页提交；接口到位后替换 `collect.py` 里的动作即可。
2. 未接入 VLM 判定；`outcome.json` 已预留 `vlm_judge` / `agree_with_label` 字段。
3. 未实现全局键鼠钩子（当前为脚本插桩模式，动作边界更准）。
4. 截图只含应用窗口，不含桌面其它内容。