"""生成交付物：summary.csv / viewer.html / REPORT.md。"""
import csv
import html
import json
from datetime import datetime
from pathlib import Path

from trajectory_recorder import load_episode

BASE = Path(__file__).parent
EP = BASE / "episodes"


def main():
    rows, episodes = [], []
    for d in sorted(EP.iterdir()):
        if not d.is_dir():
            continue
        ep = load_episode(d)
        meta, steps, outcome = ep["meta"], ep["steps"], ep["outcome"]
        passed = outcome.get("outcome", {}).get("passed")
        detail = outcome.get("outcome", {}).get("evidence", {})
        dur = ""
        if meta.get("ended_at"):
            dur = round((datetime.fromisoformat(meta["ended_at"]) -
                         datetime.fromisoformat(meta["started_at"])).total_seconds(), 2)
        rows.append({
            "task_id": meta["task_id"],
            "task_name": meta["task_name"],
            "status": meta["status"],
            "steps": len(steps),
            "duration_s": dur,
            "passed": passed,
            "evidence": json.dumps(detail, ensure_ascii=False),
            "errors": len(ep["errors"]),
        })
        episodes.append(ep)

    with open(BASE / "summary.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    parts = ["""<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">
<title>轨迹回看</title><style>
body{font-family:"Microsoft YaHei UI",sans-serif;margin:24px;background:#f6f8fb;color:#1b1f24}
h1{font-size:22px} h2{font-size:17px;margin-top:32px;border-left:4px solid #0b5cad;padding-left:10px}
.meta{color:#5b6572;font-size:13px;margin:6px 0 12px}
table{border-collapse:collapse;width:100%;background:#fff;font-size:13px}
th,td{border:1px solid #e3e7ed;padding:6px 8px;vertical-align:top}
th{background:#f3f6fa}
img{width:340px;border:1px solid #dfe4ea;border-radius:4px}
.ok{color:#157347;font-weight:600}.err{color:#b42318;font-weight:600}
</style></head><body><h1>GUI 轨迹回看</h1>"""]

    for ep in episodes:
        m, steps, oc = ep["meta"], ep["steps"], ep["outcome"]
        rel = "episodes/" + Path(ep["dir"]).name
        cls = "ok" if m["status"] == "success" else "err"
        parts.append(f"<h2>{html.escape(m['task_id'])}　<span class='{cls}'>{m['status']}</span></h2>")
        parts.append(f"<div class='meta'>任务：{html.escape(m['task_name'])}　步数：{len(steps)}　"
                     f"开始：{m['started_at']}　结果：{html.escape(json.dumps(oc.get('outcome', {}), ensure_ascii=False))}</div>")
        parts.append("<table><tr><th>#</th><th>动作</th><th>操作前</th><th>操作后</th><th>结果 / 备注</th></tr>")
        for s in steps:
            parts.append(
                f"<tr><td>{s['step_id']}</td><td>{html.escape(json.dumps(s['action'], ensure_ascii=False))}</td>"
                f"<td><img src='{rel}/{s['pre_img']}'></td>"
                f"<td><img src='{rel}/{s['post_img']}'></td>"
                f"<td>{html.escape(s.get('result', ''))}<br>{html.escape(s.get('note', ''))}</td></tr>")
        parts.append("</table>")
    parts.append("</body></html>")
    (BASE / "viewer.html").write_text("".join(parts), encoding="utf-8")

    n_ok = sum(1 for r in rows if r["status"] == "success")
    total_steps = sum(int(r["steps"]) for r in rows)
    durs = [float(r["duration_s"]) for r in rows if r["duration_s"] != ""]
    avg_dur = round(sum(durs) / len(durs), 2) if durs else ""
    shots = list(EP.glob("*/screenshots/*.png"))
    shot_mb = round(sum(p.stat().st_size for p in shots) / 1024 / 1024, 1)

    vlm_lines = []
    vlm_csv = BASE / "vlm_report.csv"
    if vlm_csv.exists():
        vlm_rows = list(csv.DictReader(open(vlm_csv, encoding="utf-8-sig")))
        done = [r for r in vlm_rows if r["status"] == "done"]
        if done:
            acc = sum(1 for r in done if r["agree"] == "True") / len(done)
            vlm_lines = ["", "## VLM 结果判定", "",
                         f"- 已判定 {len(done)} 条，与人工标签一致率 **{acc:.1%}**", ""]
        else:
            vlm_lines = ["", "## VLM 结果判定", "",
                         "- 状态：**未执行**（环境无 VLM_API_KEY / OPENAI_API_KEY）",
                         "- 接口已就绪（`vlm_judge.py`），配置 key 后执行：",
                         "  ```powershell",
                         "  set VLM_API_KEY=...",
                         "  ..\\.venv\\Scripts\\python.exe vlm_judge.py --all",
                         "  ```", ""]

    lines = [
        "# 轨迹采集结果报告",
        "",
        f"- 轨迹数量：{len(rows)} 条（成功 {n_ok} 条，失败 {len(rows) - n_ok} 条）",
        f"- 总步数：{total_steps} 步，平均每条 {round(total_steps / len(rows), 1)} 步",
        f"- 平均耗时：{avg_dur} 秒/条",
        f"- 截图：{len(shots)} 张，合计 {shot_mb} MB",
        "- 任务类型：文件保存、表单提交（替身任务，等待接入易木真实任务）",
        "- 每条轨迹：2–3 个动作，每个动作前后各一张截图（只截应用窗口）",
        "",
        "## 汇总",
        "",
        "| 任务编号 | 任务 | 状态 | 步数 | 耗时(s) | 校验通过 |",
        "| --- | --- | --- | --- | --- | --- |",
    ]
    for r in rows:
        lines.append(f"| {r['task_id']} | {r['task_name']} | {r['status']} | {r['steps']} | {r['duration_s']} | {r['passed']} |")
    lines += [
        "",
        "## 失败样本怎么造",
        "",
        "- 文件保存：保存路径设为不存在的盘符 `Z:/no_such_dir/...`，写入抛 `FileNotFoundError`；",
        "- 表单提交：邮箱填成 `user4example.com`（缺 `@`），界面提示“邮箱格式错误”。",
        "",
        "## 校验方式",
        "",
        "- 文件保存：检查目标文件是否真的生成；",
        "- 表单提交：检查界面状态“提交成功”，并核对 `sandbox/web/submissions.csv`。",
        "",
        "## 复现",
        "",
        "```powershell",
        "cd \"C:\\Users\\shhbi\\Desktop\\Computer Vision\\2026.11.15\"",
        "..\\.venv\\Scripts\\python.exe collect.py",
        "..\\.venv\\Scripts\\python.exe make_report.py",
        "```",
        "",
        *vlm_lines,
        "## 任务要求对照",
        "",
        "| 要求 | 交付物 | 状态 |",
        "| --- | --- | --- |",
        "| 操作前截图 | `steps.jsonl` 的 `pre_img` | ✅ |",
        "| 执行动作 | `steps.jsonl` 的 `action` | ✅ |",
        "| 操作后截图 | `steps.jsonl` 的 `post_img` | ✅ |",
        "| 时间 | `ts_before` / `ts_after` / `duration_ms` | ✅ |",
        "| 任务编号 | `meta.json` 的 `task_id` | ✅ |",
        "| 执行结果 | `outcome.json` 的 `status` + `passed` | ✅ |",
        "| 完整任务保存并重新读取 | `Recorder` + `load_episode` | ✅ |",
        "| 正常 + 失败两类轨迹 | 各 6 条 | ✅ |",
        "| 接入易木任务 | — | ⏳ 按要求暂缓 |",
        "| VLM 判定 | `vlm_judge.py` | ⏳ 无 key，接口就绪 |",
        "",
        "## 局限",
        "",
        "1. 目前是替身任务（Tk 窗口），不是易木的文件保存/网页提交；接口到位后替换 `collect.py` 里的动作即可。",
        "2. 未接入 VLM 判定；`outcome.json` 已预留 `vlm_judge` / `agree_with_label` 字段。",
        "3. 未实现全局键鼠钩子（当前为脚本插桩模式，动作边界更准）。",
        "4. 截图只含应用窗口，不含桌面其它内容。",
    ]
    (BASE / "REPORT.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"OK: {len(rows)} 条轨迹 -> summary.csv / viewer.html / REPORT.md")


if __name__ == "__main__":
    main()
