# 运行说明（2026.11.15 轨迹采集）

## 0. 首次使用（换机器 / 没有 .venv）

1. 双击 **`setup.bat`**：自动创建 `.venv` 并安装 `requirements.txt`（只有 Pillow）；
2. 再双击 **`run_all.bat`**。

已有 Python 环境时也可以手动：

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
```

要求：Python 3.10+，Windows（Tkinter 是标准库，一般自带）。

---

## 1. 先确认环境

- 位置：`C:\Users\shhbi\Desktop\Computer Vision\2026.11.15\`
- 解释器：**必须用** `..\.venv\Scripts\python.exe`（Python 3.11）
- 不要用系统 Python 3.13，也不要双击 `.py` 文件（会选错解释器）

检查一句：

```powershell
cd "C:\Users\shhbi\Desktop\Computer Vision\2026.11.15"
..\.venv\Scripts\python.exe -c "import PIL, tkinter; print('ok')"
```

输出 `ok` 即可。

---

## 1. 最快：双击 `run_all.bat`

它在同目录，双击后自动做三件事：

1. `demo_episode.py`：自测“写入→读取→校验”闭环；
2. `collect.py`：采集 12 条真实轨迹（会弹出窗口，**期间不要手动操作**）；
3. `make_report.py`：生成 `summary.csv`、`viewer.html`、`REPORT.md`。

跑完自动打开 `viewer.html`。

总耗时约 **1 分钟**。

---

## 2. 命令行：分步跑

```powershell
cd "C:\Users\shhbi\Desktop\Computer Vision\2026.11.15"

# ① 自测（不弹窗、不截图）
..\.venv\Scripts\python.exe demo_episode.py

# ② 采集 12 条（会弹窗约 30 秒）
..\.venv\Scripts\python.exe collect.py

# ③ 生成汇总与回看页
..\.venv\Scripts\python.exe make_report.py

# ④ 看结果
start viewer.html
```

---

## 3. 每一步会看到什么

| 步骤 | 预期输出 | 耗时 |
|---|---|---|
| demo_episode | `状态: success 步数: 3`、`OK: 写入-读取-校验 闭环通过` | 1 秒 |
| collect | 一张 12 行的表：`file_save 1 True True` … `共 12 条轨迹，成功 6 条，失败 6 条` | 约 30 秒 |
| make_report | `OK: 12 条轨迹 -> summary.csv / viewer.html / REPORT.md` | 1 秒 |

---

## 4. 结果在哪

```
2026.11.15/
├── episodes/                 # 12 个任务目录
│   ├── file_save_0001/
│   │   ├── meta.json         # 任务号、起止时间、状态
│   │   ├── steps.jsonl       # 每步动作 + 前后截图 + 结果
│   │   ├── outcome.json      # 校验证据
│   │   └── screenshots/      # 0001_pre.png / 0001_post.png ...
│   └── ...
├── summary.csv               # 一览表（Excel 可直接打开）
├── viewer.html               # 前后截图对照（双击打开）
└── REPORT.md                 # 结果报告
```

打开 `viewer.html` 后，每条轨迹一张表：动作、操作前截图、操作后截图、结果与备注。

---

## 5. 常见问题

| 现象 | 原因 | 解决 |
|---|---|---|
| `No module named 'PIL'` / `'tkinter'` | 用了系统 Python | 用 `..\.venv\Scripts\python.exe` |
| 双击 `.py` 一闪而过 | 报错窗口自动关闭 | 改用 `.bat` 或在 PowerShell 里跑 |
| 控制台中文乱码 | 控制台编码是 GBK | 文件本身是 UTF-8，不影响数据；用 `chcp 65001` 可正常显示 |
| 采集时窗口挡住别的东西 | 窗口置顶 | 属正常，约 30 秒结束 |
| 重复运行后轨迹变少 | `collect.py` 每次会清空 `episodes/` 重采 | 想保留就先把 `episodes` 改名备份 |

---

## 6. 只跑一个任务（不跑 12 条）

```powershell
..\.venv\Scripts\python.exe -c "from collect import run_file_save; print(run_file_save(99, True))"
```

会生成 `episodes/file_save_0099/`，成功返回 `True`。

---

## 7. 关于 OmegaUse-SOP

它**不在本目录运行**：需要 Python 3.12、OmniParser/PaddleOCR 服务、VLM API key，本机没有这些服务。
我们只读了它的源码（见 `OmegaUse-SOP_代码解析.md`），没有实际跑它。
