"""VLM 结果判定：给每个任务打 success / failed，并与人工标签比对。

无 key 时不会伪造结果，只记录 skipped。

配置（环境变量）：
  VLM_API_KEY / OPENAI_API_KEY   API 密钥
  VLM_BASE_URL                    默认 https://api.openai.com/v1
  VLM_MODEL                       默认 gpt-4o-mini

用法：
  ..\\.venv\\Scripts\\python.exe vlm_judge.py --all
  ..\\.venv\\Scripts\\python.exe vlm_judge.py --episode episodes/file_save_0001
"""
import argparse
import base64
import csv
import json
import os
import urllib.request
from pathlib import Path

from trajectory_recorder import load_episode

BASE = Path(__file__).parent
EP = BASE / "episodes"

PROMPT = """你是 GUI 任务结果判定器。
任务：{task}
最后一步动作：{action}
最后一步之后的状态见附图。
请只输出一个词：success 或 failed。
"""


def config():
    key = os.environ.get("VLM_API_KEY") or os.environ.get("OPENAI_API_KEY")
    base = os.environ.get("VLM_BASE_URL", "https://api.openai.com/v1").rstrip("/")
    model = os.environ.get("VLM_MODEL", "gpt-4o-mini")
    return key, base, model


def call_vlm(key, base, model, text, image_path):
    b64 = base64.b64encode(Path(image_path).read_bytes()).decode()
    payload = {
        "model": model,
        "temperature": 0,
        "messages": [{
            "role": "user",
            "content": [
                {"type": "text", "text": text},
                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}},
            ],
        }],
    }
    req = urllib.request.Request(
        base + "/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=90) as r:
        data = json.loads(r.read())
    return data["choices"][0]["message"]["content"].strip()


def parse_verdict(text):
    t = text.lower()
    if "success" in t:
        return "success"
    if "failed" in t or "fail" in t:
        return "failed"
    return "unknown"


def judge_episode(ep_dir, key, base, model):
    ep = load_episode(ep_dir)
    meta, steps = ep["meta"], ep["steps"]
    if not steps:
        return {"task_id": meta["task_id"], "label": meta["status"], "verdict": None,
                "agree": None, "status": "skipped", "reason": "no_steps"}

    last = steps[-1]
    post = Path(ep["dir"]) / last["post_img"]
    text = PROMPT.format(task=meta["task_name"],
                         action=json.dumps(last["action"], ensure_ascii=False))

    if not key:
        return {"task_id": meta["task_id"], "label": meta["status"], "verdict": None,
                "agree": None, "status": "skipped", "reason": "no_api_key"}

    verdict = parse_verdict(call_vlm(key, base, model, text, post))
    agree = (verdict == meta["status"])

    # 写回 outcome.json
    outcome_path = Path(ep["dir"]) / "outcome.json"
    outcome = json.loads(outcome_path.read_text(encoding="utf-8"))
    outcome.setdefault("outcome", {})
    outcome["outcome"]["vlm_judge"] = {"verdict": verdict, "model": model}
    outcome["outcome"]["agree_with_label"] = agree
    outcome_path.write_text(json.dumps(outcome, ensure_ascii=False, indent=2), encoding="utf-8")

    return {"task_id": meta["task_id"], "label": meta["status"], "verdict": verdict,
            "agree": agree, "status": "done", "reason": ""}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--episode", type=str, default=None)
    args = ap.parse_args()

    key, base, model = config()
    if args.episode:
        dirs = [Path(args.episode)]
    else:
        dirs = sorted(d for d in EP.iterdir() if d.is_dir())

    rows = [judge_episode(d, key, base, model) for d in dirs]

    out = BASE / "vlm_report.csv"
    with open(out, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=["task_id", "label", "verdict", "agree", "status", "reason"])
        w.writeheader()
        w.writerows(rows)

    done = [r for r in rows if r["status"] == "done"]
    skipped = [r for r in rows if r["status"] == "skipped"]
    print(f"共 {len(rows)} 条：完成 {len(done)} 条，跳过 {len(skipped)} 条")
    if done:
        acc = sum(1 for r in done if r["agree"]) / len(done)
        print(f"VLM 与人工标签一致率: {acc:.1%}")
    else:
        print("未执行 VLM 判定：未检测到 VLM_API_KEY / OPENAI_API_KEY")
        print("配置后重跑：set VLM_API_KEY=... 然后 python vlm_judge.py --all")
    print(f"明细: {out}")


if __name__ == "__main__":
    main()
