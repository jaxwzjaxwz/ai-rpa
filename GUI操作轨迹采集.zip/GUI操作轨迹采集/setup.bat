@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo Creating virtual environment in .venv ...
python -m venv .venv
if errorlevel 1 (
    echo [ERROR] Failed to create venv. Check that Python 3.10+ is on PATH.
    pause
    exit /b 1
)

echo Installing dependencies ...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] pip install failed. Check network or pip index.
    pause
    exit /b 1
)

echo.
echo Done. Now double-click run_all.bat
pause
