"""任务适配器：把「易木的动作脚本」和「结果校验」包成一个可录制任务。"""
from dataclasses import dataclass, field
from typing import Callable, Optional

from trajectory_recorder import Recorder


@dataclass
class TaskAdapter:
    task_id: str
    task_name: str
    app: str = ""
    params: dict = field(default_factory=dict)
    body: Optional[Callable] = None      # body(rec)：执行动作，内部用 rec.action(...)
    checker: Optional[Callable] = None   # checker() -> (passed: bool, evidence)
    out_root: str = "episodes"

    def run(self):
        rec = Recorder(self.task_id, self.task_name, out_root=self.out_root,
                       app=self.app, params=self.params)
        rec.start()
        status, outcome = "success", {}
        try:
            if self.body:
                self.body(rec)
        except Exception as e:
            status = "failed"
            outcome["error"] = f"{type(e).__name__}: {e}"

        if self.checker:
            try:
                passed, evidence = self.checker()
                outcome.update({"passed": bool(passed), "evidence": evidence})
                if not passed and status == "success":
                    status = "failed"
            except Exception as e:
                outcome["checker_error"] = f"{type(e).__name__}: {e}"

        rec.finish(status=status, outcome=outcome)
        return rec.dir
