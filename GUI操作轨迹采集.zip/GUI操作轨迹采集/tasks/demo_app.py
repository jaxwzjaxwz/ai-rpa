"""替身任务窗口：文件保存 + 表单提交，用于在等易木接口期间采集真实轨迹。

窗口只截自身区域（bbox），不会把桌面其它内容录进去。
"""
import csv
from pathlib import Path

import tkinter as tk
from PIL import ImageGrab


class DemoApp:
    def __init__(self, root, workdir="sandbox"):
        self.root = root
        self.workdir = Path(workdir)
        self.workdir.mkdir(parents=True, exist_ok=True)
        self.last = {"ok": None, "detail": ""}

        root.title("轨迹采集替身任务（文件保存 / 表单提交）")
        root.geometry("900x640+80+80")
        root.attributes("-topmost", True)
        root.configure(bg="#f5f7fa")

        # ---- 文件保存 ----
        tk.Label(root, text="① 文件保存", font=("Microsoft YaHei UI", 13, "bold"),
                 bg="#f5f7fa").place(x=30, y=15)
        tk.Label(root, text="内容：", bg="#f5f7fa").place(x=30, y=55)
        self.text_var = tk.StringVar()
        tk.Entry(root, textvariable=self.text_var, width=70).place(x=90, y=53)
        tk.Label(root, text="路径：", bg="#f5f7fa").place(x=30, y=95)
        self.path_var = tk.StringVar()
        tk.Entry(root, textvariable=self.path_var, width=70).place(x=90, y=93)
        self.save_btn = tk.Button(root, text="保存文件", width=14, command=self.save_file)
        self.save_btn.place(x=90, y=130)
        self.status_var = tk.StringVar(value="等待操作")
        tk.Label(root, textvariable=self.status_var, fg="#0b5cad", bg="#f5f7fa").place(x=230, y=135)

        # ---- 表单提交 ----
        tk.Label(root, text="② 表单提交", font=("Microsoft YaHei UI", 13, "bold"),
                 bg="#f5f7fa").place(x=30, y=200)
        tk.Label(root, text="姓名：", bg="#f5f7fa").place(x=30, y=240)
        self.name_var = tk.StringVar()
        tk.Entry(root, textvariable=self.name_var, width=40).place(x=90, y=238)
        tk.Label(root, text="邮箱：", bg="#f5f7fa").place(x=30, y=280)
        self.email_var = tk.StringVar()
        tk.Entry(root, textvariable=self.email_var, width=40).place(x=90, y=278)
        self.submit_btn = tk.Button(root, text="提交表单", width=14, command=self.submit)
        self.submit_btn.place(x=90, y=315)
        self.form_status_var = tk.StringVar(value="等待操作")
        tk.Label(root, textvariable=self.form_status_var, fg="#0b5cad", bg="#f5f7fa").place(x=230, y=320)

        self.root.update()

    # ---- 动作实现 ----
    def save_file(self):
        path = Path(self.path_var.get())
        try:
            path.write_text(self.text_var.get(), encoding="utf-8")
            self.status_var.set("保存成功")
            self.last = {"ok": True, "detail": str(path)}
        except Exception as e:
            self.status_var.set(f"保存失败：{type(e).__name__}")
            self.last = {"ok": False, "detail": f"{type(e).__name__}: {e}"}
        self.root.update()

    def submit(self):
        name, email = self.name_var.get().strip(), self.email_var.get().strip()
        if not name:
            self.form_status_var.set("提交失败：姓名为空")
            self.last = {"ok": False, "detail": "name empty"}
        elif "@" not in email:
            self.form_status_var.set("提交失败：邮箱格式错误")
            self.last = {"ok": False, "detail": f"bad email: {email!r}"}
        else:
            with open(self.workdir / "submissions.csv", "a", newline="", encoding="utf-8") as f:
                csv.writer(f).writerow([name, email])
            self.form_status_var.set("提交成功")
            self.last = {"ok": True, "detail": f"{name} <{email}>"}
        self.root.update()


def window_capture(root):
    """只截 Tk 窗口自身的区域，避免录到桌面其它内容。"""
    def _cap(path):
        root.update_idletasks()
        root.update()
        x, y = root.winfo_rootx(), root.winfo_rooty()
        w, h = root.winfo_width(), root.winfo_height()
        img = ImageGrab.grab(bbox=(x, y, x + w, y + h))
        img.save(path, "PNG")
        return img.size
    return _cap
