"""结果校验器：返回 (passed: bool, evidence: dict)。"""
from pathlib import Path
from urllib.request import urlopen


def file_exists(path):
    p = Path(path)
    return p.exists(), {"path": str(p), "is_file": p.is_file(),
                        "size": p.stat().st_size if p.exists() else 0}


def file_contains(path, text):
    p = Path(path)
    if not p.exists():
        return False, {"path": str(p), "reason": "文件不存在"}
    content = p.read_text(encoding="utf-8", errors="ignore")
    ok = text in content
    return ok, {"path": str(p), "expect": text, "found": ok, "chars": len(content)}


def http_contains(url, text, timeout=10):
    try:
        with urlopen(url, timeout=timeout) as r:
            body = r.read().decode("utf-8", errors="ignore")
            ok = text in body
            return ok, {"url": url, "status": r.status, "expect": text, "found": ok}
    except Exception as e:
        return False, {"url": url, "error": f"{type(e).__name__}: {e}"}
