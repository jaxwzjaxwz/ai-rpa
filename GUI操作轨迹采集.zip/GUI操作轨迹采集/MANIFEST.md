﻿# 压缩包文件清单（MANIFEST）

> 本包共 121 个文件、约 2.3 MB。解压后目录结构与 `2026.11.15/` 一致。
> 建议阅读顺序：**交付说明 → REPORT → viewer.html → DATA_FORMAT → RUN → 代码**。

---

## 一、根目录文档

| 文件 | 一句话说明 | 给谁看 |
|---|---|---|
| `交付说明.docx` | 交付说明（用户修订版）：交了什么、怎么验收、结果摘要、要求对照 | 主管 / 验收人 |
| `REPORT.md` / `REPORT.docx` | 结果报告：12 条轨迹统计、失败样本构造、VLM 状态 | 主管 / 评审 |
| `DATA_FORMAT.md` | 数据格式：目录结构、字段表、示例、体积估算 | 接手的开发 |
| `schema.json` | 机器可读的 JSON Schema，可用于校验 | 开发 |
| `README.md` | 项目说明：目标、与 OmegaUse-SOP 的对应、当前状态 | 任何人 |
| `RUN.md` | 运行说明：一键/分步命令、预期输出、常见问题 | 运行的人 |
| `MANIFEST.md` | 本文件：包内每个文件是什么 | 任何人 |
| `OmegaUse-SOP_代码解析.md` | 竞品源码调研：采集机制、Reason/Execute、逐行注释 | 技术调研 |

---

## 二、代码（`trajectory_recorder/` 与 `tasks/`）

### `trajectory_recorder/` —— 轨迹记录核心

| 文件 | 作用 |
|---|---|
| `__init__.py` | 对外导出 `Recorder`、`load_episode`、`list_episodes` |
| `recorder.py` | 核心类 `Recorder`：`action()` 上下文管理器，进入时截“前”图、退出时截“后”图，写 `steps.jsonl`；`finish()` 写 `outcome.json` |
| `loader.py` | 读取一条/全部轨迹，校验必填字段与图片存在性，打印汇总表 |
| `screenshot.py` | 截图封装：声明 DPI 感知，抓全屏并保存 PNG |

### `tasks/` —— 任务适配与校验

| 文件 | 作用 |
|---|---|
| `__init__.py` | 包标记（空文件） |
| `base.py` | `TaskAdapter`：把“动作函数 + 校验函数”包成一个可录制任务 |
| `checks.py` | 三个校验器：`file_exists`、`file_contains`、`http_contains` |
| `demo_app.py` | 替身任务窗口（Tkinter）：文件保存 + 表单提交，只截自身区域 |

### 根目录的 Python 脚本

| 文件 | 作用 | 什么时候用 |
|---|---|---|
| `collect.py` | 采集 12 条轨迹（6 成功 + 6 失败），会清空 `episodes/` | 采集数据 |
| `make_report.py` | 生成 `summary.csv`、`viewer.html`、`REPORT.md` | 出结果 |
| `vlm_judge.py` | 调 VLM 判定每条轨迹成败，与人工标签比对 | 有 API key 时 |
| `demo_episode.py` | 不依赖 GUI 的自测：造一条 3 步假轨迹并读回校验 | 验证代码 |

### 根目录批处理 / 环境文件

| 文件 | 作用 |
|---|---|
| `run_all.bat` | 一键：自测 → 采集 12 条 → 生成汇总并打开回看页 |
| `setup.bat` | 首次使用：创建 `.venv` 并安装 `requirements.txt` |
| `requirements.txt` | 依赖清单（只有 `pillow`） |

---

## 三、数据与结果

| 路径 | 内容 |
|---|---|
| `episodes/` | 12 个任务目录，每个任务一份完整轨迹（见下节） |
| `summary.csv` | 12 行汇总：任务号、名称、状态、步数、耗时、校验结果 |
| `vlm_report.csv` | 12 行 VLM 判定明细（当前全部 `skipped`，无 key） |
| `viewer.html` | 回看页：每条轨迹的动作、操作前截图、操作后截图、结果 |

### 单条轨迹目录（以 `file_save_0001` 为例）

```
file_save_0001/
├── meta.json          # 任务号、任务名、操作人、起止时间、状态、环境
├── steps.jsonl        # 每行一个动作：动作、目标、前后截图、时间、结果
├── outcome.json       # 任务结果：passed、证据（文件路径/错误信息）
└── screenshots/
    ├── 0001_pre.png   # 第 1 步操作前
    ├── 0001_post.png  # 第 1 步操作后
    ├── 0002_pre.png
    └── 0002_post.png
```

- `file_save_*`：2 步 → 4 张图；
- `web_submit_*`：3 步 → 6 张图；
- 合计 12 条、30 个动作、60 张截图。

---

## 四、体积与数量

| 项 | 数值 |
|---|---|
| 文件总数 | 123 |
| 压缩包大小 | 约 2.3 MB |
| 轨迹数 | 12 条（成功 6 / 失败 6） |
| 动作数 | 30 步 |
| 截图 | 60 张，约 2.3 MB |
| 代码行数 | 约 600 行（不含第三方库） |

---

## 五、最小验收路径

1. 打开 `交付说明.docx` 看交付范围；
2. 打开 `viewer.html` 看轨迹长什么样；
3. 双击 `run_all.bat`（需在解压目录内，且上一级有 `.venv`）复跑一遍；
4. 想接自己的任务，看 `DATA_FORMAT.md` 与 `tasks/base.py`。
